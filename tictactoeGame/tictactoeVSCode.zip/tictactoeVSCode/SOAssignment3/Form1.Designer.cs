﻿namespace tictactoeGame
{
    partial class TicTacToe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TicTacToe));
            this.a0 = new System.Windows.Forms.Button();
            this.a1 = new System.Windows.Forms.Button();
            this.a2 = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.c0 = new System.Windows.Forms.Button();
            this.c1 = new System.Windows.Forms.Button();
            this.c2 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.User1 = new System.Windows.Forms.Label();
            this.User2 = new System.Windows.Forms.Label();
            this.User1ScoreLbl = new System.Windows.Forms.Label();
            this.User2ScoreLbl = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.resetGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // a0
            // 
            this.a0.BackColor = System.Drawing.Color.Bisque;
            this.a0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a0.ForeColor = System.Drawing.Color.Beige;
            this.a0.Location = new System.Drawing.Point(29, 42);
            this.a0.Name = "a0";
            this.a0.Size = new System.Drawing.Size(130, 114);
            this.a0.TabIndex = 0;
            this.a0.UseVisualStyleBackColor = false;
            this.a0.Click += new System.EventHandler(this.BtnClicked);
            // 
            // a1
            // 
            this.a1.BackColor = System.Drawing.Color.Bisque;
            this.a1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a1.Location = new System.Drawing.Point(165, 42);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(130, 114);
            this.a1.TabIndex = 1;
            this.a1.UseVisualStyleBackColor = false;
            this.a1.Click += new System.EventHandler(this.BtnClicked);
            // 
            // a2
            // 
            this.a2.BackColor = System.Drawing.Color.Bisque;
            this.a2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a2.Location = new System.Drawing.Point(301, 42);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(130, 114);
            this.a2.TabIndex = 2;
            this.a2.UseVisualStyleBackColor = false;
            this.a2.Click += new System.EventHandler(this.BtnClicked);
            // 
            // b0
            // 
            this.b0.BackColor = System.Drawing.Color.Bisque;
            this.b0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b0.Location = new System.Drawing.Point(29, 162);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(130, 114);
            this.b0.TabIndex = 3;
            this.b0.UseVisualStyleBackColor = false;
            this.b0.Click += new System.EventHandler(this.BtnClicked);
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.Bisque;
            this.b2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.Location = new System.Drawing.Point(301, 162);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(130, 114);
            this.b2.TabIndex = 5;
            this.b2.UseVisualStyleBackColor = false;
            this.b2.Click += new System.EventHandler(this.BtnClicked);
            // 
            // c0
            // 
            this.c0.BackColor = System.Drawing.Color.Bisque;
            this.c0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c0.Location = new System.Drawing.Point(29, 282);
            this.c0.Name = "c0";
            this.c0.Size = new System.Drawing.Size(130, 114);
            this.c0.TabIndex = 6;
            this.c0.UseVisualStyleBackColor = false;
            this.c0.Click += new System.EventHandler(this.BtnClicked);
            // 
            // c1
            // 
            this.c1.BackColor = System.Drawing.Color.Bisque;
            this.c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1.Location = new System.Drawing.Point(165, 282);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(130, 114);
            this.c1.TabIndex = 7;
            this.c1.UseVisualStyleBackColor = false;
            this.c1.Click += new System.EventHandler(this.BtnClicked);
            // 
            // c2
            // 
            this.c2.BackColor = System.Drawing.Color.Bisque;
            this.c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c2.Location = new System.Drawing.Point(301, 282);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(130, 114);
            this.c2.TabIndex = 8;
            this.c2.UseVisualStyleBackColor = false;
            this.c2.Click += new System.EventHandler(this.BtnClicked);
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.Bisque;
            this.b1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.Location = new System.Drawing.Point(166, 162);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(130, 114);
            this.b1.TabIndex = 9;
            this.b1.UseVisualStyleBackColor = false;
            this.b1.Click += new System.EventHandler(this.BtnClicked);
            // 
            // User1
            // 
            this.User1.Location = new System.Drawing.Point(63, 428);
            this.User1.Name = "User1";
            this.User1.Size = new System.Drawing.Size(70, 24);
            this.User1.TabIndex = 10;
            this.User1.Text = "User 1";
            // 
            // User2
            // 
            this.User2.Location = new System.Drawing.Point(163, 428);
            this.User2.Name = "User2";
            this.User2.Size = new System.Drawing.Size(70, 24);
            this.User2.TabIndex = 11;
            this.User2.Text = "user 2";
            // 
            // User1ScoreLbl
            // 
            this.User1ScoreLbl.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.User1ScoreLbl.Location = new System.Drawing.Point(63, 464);
            this.User1ScoreLbl.Name = "User1ScoreLbl";
            this.User1ScoreLbl.Size = new System.Drawing.Size(36, 24);
            this.User1ScoreLbl.TabIndex = 12;
            this.User1ScoreLbl.Text = "0";
            // 
            // User2ScoreLbl
            // 
            this.User2ScoreLbl.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.User2ScoreLbl.Location = new System.Drawing.Point(163, 464);
            this.User2ScoreLbl.Name = "User2ScoreLbl";
            this.User2ScoreLbl.Size = new System.Drawing.Size(38, 24);
            this.User2ScoreLbl.TabIndex = 13;
            this.User2ScoreLbl.Text = "0";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetGameToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(467, 28);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // resetGameToolStripMenuItem
            // 
            this.resetGameToolStripMenuItem.Name = "resetGameToolStripMenuItem";
            this.resetGameToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.resetGameToolStripMenuItem.Text = "Reset Game";
            this.resetGameToolStripMenuItem.Click += new System.EventHandler(this.resetGameToolStripMenuItem_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "tic-tac-toe-X.png");
            this.imageList1.Images.SetKeyName(1, "tic-tac-toe-O.png");
            // 
            // TicTacToe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 538);
            this.Controls.Add(this.User2ScoreLbl);
            this.Controls.Add(this.User1ScoreLbl);
            this.Controls.Add(this.User2);
            this.Controls.Add(this.User1);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.c2);
            this.Controls.Add(this.c1);
            this.Controls.Add(this.c0);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.a1);
            this.Controls.Add(this.a0);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "TicTacToe";
            this.Text = "Game";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button a0;
        private System.Windows.Forms.Button a1;
        private System.Windows.Forms.Button a2;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button c0;
        private System.Windows.Forms.Button c1;
        private System.Windows.Forms.Button c2;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Label User1;
        private System.Windows.Forms.Label User2;
        private System.Windows.Forms.Label User1ScoreLbl;
        private System.Windows.Forms.Label User2ScoreLbl;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem resetGameToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList1;
    }
}

