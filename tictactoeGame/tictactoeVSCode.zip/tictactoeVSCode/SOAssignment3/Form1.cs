﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//TIC TAC TOE Game done by Sheik Oodally

namespace tictactoeGame
{
    public partial class TicTacToe : Form
    {

        public TicTacToe()
        {
            InitializeComponent();
        }


        int UsrWin = 0; //user 11
        int Usr2 = 0; //user 2
        int turn = 0;

        private void BtnClicked(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (turn % 2 == 0)
            {
                btn.Image = imageList1.Images[0];
                btn.Enabled = false;
                btn.BackColor = Color.Green;
                turn++;
                CheckWinner();
            }
            else if (turn % 2 == 1)
            {
                btn.Image = imageList1.Images[1];
                btn.Enabled = false;
                btn.BackColor = Color.Red;
                turn++;
                CheckWinner();

            }
        }


        private void CheckWinner() //verifies on each turn if there is a winner
        {
            if (a0.BackColor == Color.Green && a1.BackColor == Color.Green && a2.BackColor == Color.Green ||
                b0.BackColor == Color.Green && b1.BackColor == Color.Green && b2.BackColor == Color.Green ||
                c0.BackColor == Color.Green && c1.BackColor == Color.Green && c2.BackColor == Color.Green ||
                a0.BackColor == Color.Green && b1.BackColor == Color.Green && c2.BackColor == Color.Green ||
                c0.BackColor == Color.Green && b1.BackColor == Color.Green && a2.BackColor == Color.Green ||
                a1.BackColor == Color.Green && b1.BackColor == Color.Green && c1.BackColor == Color.Green ||
                a0.BackColor == Color.Green && b0.BackColor == Color.Green && c0.BackColor == Color.Green ||
                a2.BackColor == Color.Green && b2.BackColor == Color.Green && c2.BackColor == Color.Green)
            {

                MessageBox.Show("Player 1 Wins");
                UsrWin++;
                User1ScoreLbl.Text = UsrWin.ToString();
                ResetGame();
            }
            else
            if (a0.BackColor == Color.Red && a1.BackColor == Color.Red && a2.BackColor == Color.Red ||
                b0.BackColor == Color.Red && b1.BackColor == Color.Red && b2.BackColor == Color.Red ||
                c0.BackColor == Color.Red && c1.BackColor == Color.Red && c2.BackColor == Color.Red ||
                a0.BackColor == Color.Red && b1.BackColor == Color.Red && c2.BackColor == Color.Red ||
                c0.BackColor == Color.Red && b1.BackColor == Color.Red && a2.BackColor == Color.Red ||
                a1.BackColor == Color.Red && b1.BackColor == Color.Red && c1.BackColor == Color.Red ||
                a0.BackColor == Color.Red && b0.BackColor == Color.Red && c0.BackColor == Color.Red ||
                a2.BackColor == Color.Red && b2.BackColor == Color.Red && c2.BackColor == Color.Red)
            {
                MessageBox.Show("Player 2 Wins");
                Usr2++;
                User2ScoreLbl.Text = Usr2.ToString();
                ResetGame();
            }
            else if (turn == 8)
            {
                MessageBox.Show("Match Draw");
                ResetGame();
            }
        }

        private void ResetGame()
        {
            foreach (Control X in this.Controls)
            {
                if (X is Button)
                {
                    ((Button)X).Enabled = true; 
                    ((Button)X).Text = "";
                    turn = 0;
                    ((Button)X).Image = null;
                    ((Button)X).BackColor = Color.Bisque;
                }
            }
        }

        private void resetGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UsrWin = 0;
            Usr2 = 0;
            User2ScoreLbl.Text = "0";
            User1ScoreLbl.Text = "0";
            ResetGame();
        }
    }
}
