﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using p4_primitivesLibrary;
using System;
using System.Collections.Generic;

namespace HalloweenWalker
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        public SpriteBatch spriteBatch;
        private startingPage StartingPage;
        private playScene PlayScene;
        private HelpPage helpPage;
        private creditPage CreditPage;
        private GameOverScreen gameOverScreen;
        private HighScorePage highScorePage;
        private level1 Level1;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.PreferredBackBufferHeight = 701;
            graphics.PreferredBackBufferWidth = 1192;

            IsMouseVisible = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {

            Shared.stage = new Vector2(graphics.PreferredBackBufferWidth,
                graphics.PreferredBackBufferHeight);
            // TODO: Add your initialization logic here
            base.Initialize();
        }

        private void hideAllScenes()
        {
            Scene GameStarts = null;
            foreach (GameComponent item in Components)
            {
                if (item is Scene)
                {
                    GameStarts = (Scene)item;
                    GameStarts.hide();
                }
            }
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            StartingPage = new startingPage(this);
            this.Components.Add(StartingPage);
            StartingPage.show();

            //create other scenes here and add to component list
            PlayScene = new playScene(this);
            this.Components.Add(PlayScene);

            helpPage = new HelpPage(this);
            this.Components.Add(helpPage);

            CreditPage = new creditPage(this);
            this.Components.Add(CreditPage);

            gameOverScreen = new GameOverScreen(this);
            this.Components.Add(gameOverScreen);

            highScorePage = new HighScorePage(this);
            this.Components.Add(highScorePage);

            Level1 = new level1(this);
            this.Components.Add(Level1);

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

       
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            int selectedIndex = 0;

            KeyboardState ks = Keyboard.GetState();

            if (StartingPage.Enabled)
            {
                selectedIndex = StartingPage.Menu.SelectedIndex;
                if (selectedIndex == 0 && ks.IsKeyDown(Keys.Enter))
                {
                    hideAllScenes();
                    PlayScene.show();
                }
                else if (selectedIndex == 1 && ks.IsKeyDown(Keys.Enter))
                {
                    hideAllScenes();
                    helpPage.show();
                }
                else if (selectedIndex == 2 && ks.IsKeyDown(Keys.Enter))
                {
                    hideAllScenes();
                    highScorePage.show();
                }
                else if (selectedIndex == 3 && ks.IsKeyDown(Keys.Enter))
                {
                    hideAllScenes();
                    CreditPage.show();
                }
                //handle other menu options
                else if (selectedIndex == 4 && ks.IsKeyDown(Keys.Enter))
                {
                    Exit();
                }              
            }


            if (Fire.check==true)
            {
                if (ks.IsKeyDown(Keys.Escape))
                {
                    Fire.check = false;
                    coins.points = 0;
                }
                PlayScene.hide();
                gameOverScreen.show();              
            }


            if (coins.winCheck == true)
            {
                if (ks.IsKeyDown(Keys.Escape))
                {

                    coins.winCheck = false;
                    coins.points = 0;
                }
                PlayScene.hide();
                Level1.show();
            }

            SoundEffect effectJump = Content.Load<SoundEffect>("jump");
            if (Player.jumping == true)
            {
                effectJump.Play(volume: 0.1f, pitch: 0.0f, pan: 0.0f);
                Player.jumping = false;
            }

            if (PlayScene.Enabled || helpPage.Enabled || CreditPage.Enabled || highScorePage.Enabled)
            {
                if (ks.IsKeyDown(Keys.Escape))
                {
                    hideAllScenes();
                    StartingPage.show();
                    
                }
            }

            SoundEffect GameOvr = Content.Load<SoundEffect>("gameoverSound");
            if (gameOverScreen.Enabled)
            {
                GameOvr.Play(volume: 0.05f, pitch: 0.0f, pan: 0.0f);
                if (ks.IsKeyDown(Keys.Escape))
                {
                    PlayScene = new playScene(this);
                    this.Components.Add(PlayScene);
                    PlayScene.show();
                }
            }

            if (Level1.Enabled)
            {
                if (ks.IsKeyDown(Keys.Escape))
                {
                    PlayScene = new playScene(this);
                    this.Components.Add(PlayScene);
                    PlayScene.show();
                }
            }


            // TODO: Add your update logic here
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            Texture2D startTexture = Content.Load<Texture2D>("startingimg");
            spriteBatch.Draw(startTexture, new Rectangle(0, 0, 1192, 701), Color.White);
            spriteBatch.End();

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
    }
}
