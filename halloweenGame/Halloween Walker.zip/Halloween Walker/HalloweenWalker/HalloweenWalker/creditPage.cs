﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HalloweenWalker
{
    class creditPage : Scene
    {
        private SpriteBatch spriteBatch;
        private Texture2D CreditImg;
        public creditPage(Game game) : base(game)
        {

            Game1 g = (Game1)game;
            this.spriteBatch = g.spriteBatch;
            CreditImg = g.Content.Load<Texture2D>("CreditPg");
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(CreditImg, Vector2.Zero, Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
