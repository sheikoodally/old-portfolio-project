﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Input;

namespace HalloweenWalker
{
    public class level1 : Scene
    {
        private SpriteBatch spriteBatch;
        private SpriteFont spriteFont;
        private Texture2D lvl1Img;
        SpriteFont RegularFont;
        public level1(Game game) : base(game)
        {
            Game1 g = (Game1)game;
            this.spriteBatch = g.spriteBatch;
            lvl1Img = g.Content.Load<Texture2D>("level1");
            SpriteFont regularFont = g.Content.Load<SpriteFont>("regularFont");
            RegularFont = regularFont;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(lvl1Img, Vector2.Zero, Color.White);
            spriteBatch.DrawString(RegularFont, "Score: " +coins.points.ToString(), new Vector2(500, 200), Color.Red);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
