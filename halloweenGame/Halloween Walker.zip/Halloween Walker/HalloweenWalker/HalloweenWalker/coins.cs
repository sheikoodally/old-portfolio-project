﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C3.XNA;
using Microsoft.Xna.Framework.Input;
using p4_primitivesLibrary;

namespace HalloweenWalker
{
        class coins : DrawableGameComponent
        {

            SpriteBatch spriteBatch;
            Texture2D coinTexture;
            Background backGround;
            SpriteFont spriteFont;
            public static int points = 0;
            public static Boolean winCheck = false;
            Vector2 pts = new Vector2(50, 50);

            List<Rectangle> coinBody;
            public List<Rectangle> COINBODYS { get => coinBody; }
            public coins(Game game, SpriteBatch spriteBatch, SpriteFont spriteFont, Texture2D playerTexture, Background b) : base(game)
            {
                this.spriteBatch = spriteBatch;
                this.coinTexture = playerTexture;
                this.backGround = b;
                this.spriteFont = spriteFont;

                coinBody = new List<Rectangle>();

                coinBody.Add(new Rectangle(155, 80, 50, 50));
                coinBody.Add(new Rectangle(260, 90, 50, 50));
                coinBody.Add(new Rectangle(135, 330, 50, 50));
                coinBody.Add(new Rectangle(186, 330, 50, 50));
                coinBody.Add(new Rectangle(237, 330, 50, 50));
                coinBody.Add(new Rectangle(30, 575, 50, 50));
                coinBody.Add(new Rectangle(81, 575, 50, 50));
                coinBody.Add(new Rectangle(132, 550, 50, 50));
                coinBody.Add(new Rectangle(1101, 577, 50, 50));
                coinBody.Add(new Rectangle(1050, 577, 50, 50));
                coinBody.Add(new Rectangle(999, 577, 50, 50));
                coinBody.Add(new Rectangle(1015, 405, 50, 50));
                coinBody.Add(new Rectangle(900, 240, 50, 50));
                coinBody.Add(new Rectangle(720, 240, 50, 50));
                coinBody.Add(new Rectangle(1035, 36, 50, 50));
                coinBody.Add(new Rectangle(1100, 31, 50, 50));
            }

            public override void Draw(GameTime gameTime)
            {
                spriteBatch.Begin();
                foreach (Rectangle r in coinBody)
                {
                    spriteBatch.Draw(coinTexture, r, Color.White);

                    spriteBatch.DrawRectangle(r, Color.Transparent);
                }

                spriteBatch.DrawString(spriteFont,"Score: " + points.ToString(), new Vector2(2 , 2), Color.GreenYellow);
                spriteBatch.End();
                base.Draw(gameTime);
            }

        Rectangle secondRect =new Rectangle (0, 0, 0, 0);
        protected void DetectCollision()
        {
            
            Rectangle firstRect = new Rectangle(Player.player.X,Player.player.Y,Player.player.Width,Player.player.Height);
            for (int i = 0; i <= 15; i++)
            {
                if (firstRect.Intersects(coinBody[i]))
                {
                    points += 100;
                    coinBody[i] = new Rectangle(5000, 5000, 5, 5);                    
                }
            }

            if (points >= 1600)
            {
                winCheck = true;
            }
        }
            public override void Update(GameTime gameTime)
            {
                DetectCollision();
                float deltaTime = (float)gameTime.ElapsedGameTime.Seconds;


            base.Update(gameTime);
            }
        }
 }



