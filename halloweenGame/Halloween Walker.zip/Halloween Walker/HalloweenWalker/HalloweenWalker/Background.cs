﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C3.XNA;
using Microsoft.Xna.Framework.Input;

namespace p4_primitivesLibrary
{
    class Background : DrawableGameComponent
    {
        SpriteBatch spritebatch;
        Texture2D backgroundTexture;
        SpriteFont spriteFont;

        List<Rectangle> rigidBodyList;
        public List<Rectangle> RigidBodyList { get => rigidBodyList; }
        public Background(Game game, SpriteBatch spriteBatch, SpriteFont spriteFont, Texture2D backgroundTexture) : base(game)
        {
            this.spritebatch = spriteBatch;
            this.backgroundTexture = backgroundTexture;
            this.spriteFont = spriteFont;

            rigidBodyList = new List<Rectangle>();


            rigidBodyList.Add(new Rectangle(0, 0, 1, 633));
            rigidBodyList.Add(new Rectangle(1190, 0, 1, 633));
            rigidBodyList.Add(new Rectangle(0, 0, 1190, 0));

            rigidBodyList.Add(new Rectangle(122, 152, 138, 58));
            rigidBodyList.Add(new Rectangle(0, 393, 318, 58));
            rigidBodyList.Add(new Rectangle(687, 291, 123, 58));
            rigidBodyList.Add(new Rectangle(868, 291, 200, 58));
            rigidBodyList.Add(new Rectangle(0, 640, 476, 60));
            rigidBodyList.Add(new Rectangle(545, 640, 847, 60));
            rigidBodyList.Add(new Rectangle(1044, 92, 148, 58));
            rigidBodyList.Add(new Rectangle(993, 463, 200, 58));

        }

        public override void Draw(GameTime gameTime)
        {
            
            spritebatch.Begin();
            spritebatch.Draw(backgroundTexture, new Rectangle(0, 0, 1192,701), Color.White);
            //debug:
            foreach(Rectangle r in rigidBodyList)
                spritebatch.DrawRectangle(r, Color.Transparent);
            spritebatch.End();
            base.Draw(gameTime);
        }
        
        public override void Update(GameTime gameTime)
        {

            base.Update(gameTime);
        }
    }
}
