﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using p4_primitivesLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Media;

namespace HalloweenWalker
{
    public class playScene : Scene
    {
        private SpriteBatch spriteBatch;
        private SpriteFont spriteFont;

        //private Bat bat;
        public playScene(Game game) : base(game)
        {
            Game1 g = (Game1)game;
            this.spriteBatch = g.spriteBatch;

            SpriteFont defaultFont = g.Content.Load<SpriteFont>("defaultFont");

            Song backgroundSong = g.Content.Load<Song>("backgroundMedia");
            MediaPlayer.Volume = 0.1f; //0=silent, 1=full
            MediaPlayer.Play(backgroundSong);

            Texture2D backgroundTexture = g.Content.Load<Texture2D>("BackgroundTexture");
            Background b = new Background(game, spriteBatch, defaultFont, backgroundTexture);
            Components.Add(b);

            SpriteFont File = g.Content.Load<SpriteFont>("File");
            Texture2D coinTexture = g.Content.Load<Texture2D>("coin_01");
            coins q = new coins(game, spriteBatch, defaultFont, coinTexture, b);
            Components.Add(q);

            Fire f = new Fire(game, spriteBatch, spriteFont, b);
            Components.Add(f);

            Ladder l = new Ladder(game, spriteBatch, spriteFont, b);
            Components.Add(l);

            Texture2D playerTexture = g.Content.Load<Texture2D>("p1_spritesheettt");

            Player p = new Player(game, spriteBatch, playerTexture, b);
            Components.Add(p);

            //Texture2D EnemyTexture = g.Content.Load<Texture2D>("p1_front");
            //Enemy e = new Enemy(game, EnemyTexture, new Vector2(200,200) , 0f);
            //Components.Add(e);

            Components.Add(p);

        }

        private void hideAllScenes()
        {
            Scene GameStarts = null;
            foreach (GameComponent item in Components)
            {
                if (item is Scene)
                {
                    GameStarts = (Scene)item;
                    GameStarts.hide();
                }
            }
        }

        public override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            {
                hideAllScenes();

            }
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);
        }
    }
}
