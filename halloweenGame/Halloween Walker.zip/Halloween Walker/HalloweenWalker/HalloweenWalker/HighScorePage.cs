﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HalloweenWalker
{
    class HighScorePage : Scene
    {
        private SpriteBatch spriteBatch;
        private Texture2D ScoreImg;
        SpriteFont RegularFont;
        int loc = 0;
        int[] pointCollection = new int[5];
        
        public HighScorePage(Game game) : base(game)
        {

            Game1 g = (Game1)game;
            this.spriteBatch = g.spriteBatch;
            ScoreImg = g.Content.Load<Texture2D>("highScoreImg");
            SpriteFont regularFont = g.Content.Load<SpriteFont>("regularFont");
            RegularFont = regularFont;

            pointCollection[0] = 0;
            pointCollection[0] = 0;
            pointCollection[0] = 0;
            pointCollection[0] = 0;
            pointCollection[0] = 0;



            for (int pts = 0; pts < 5; pts++)
            {
                if (pointCollection[pts] < coins.points)
                {
                    pointCollection[pts] = coins.points;
                }
            }
            

        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(ScoreImg, Vector2.Zero, Color.White);
            for (int ten = 0; ten < 5; ten++)
            {
                if(ten == 0)
                {
                    spriteBatch.DrawString(RegularFont, "Player 1 Score: " + pointCollection[ten], new Vector2(262, 180), Color.Red);
                }
                else if (ten == 1)
                {
                    spriteBatch.DrawString(RegularFont, "Player 2 Score: " + pointCollection[ten], new Vector2(262, 200), Color.Red);
                }
                else if (ten == 2)
                {
                    spriteBatch.DrawString(RegularFont, "Player 3 Score: " + pointCollection[ten], new Vector2(262, 220), Color.Red);
                }
                else if (ten == 3)
                {
                    spriteBatch.DrawString(RegularFont, "Player 4 Score: " + pointCollection[ten], new Vector2(262, 240), Color.Red);
                }
                else if (ten == 4)
                {
                    spriteBatch.DrawString(RegularFont, "Player 5 Score: " + pointCollection[ten], new Vector2(262, 260), Color.Red);
                }

            }
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}