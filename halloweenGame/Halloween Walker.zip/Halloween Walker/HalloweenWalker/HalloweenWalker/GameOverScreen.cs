﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C3.XNA;
using Microsoft.Xna.Framework.Input;
using p4_primitivesLibrary;


namespace HalloweenWalker
{
    class GameOverScreen : Scene
    {

        private SpriteBatch spriteBatch;
        private Texture2D helpImg;
        SpriteFont RegularFont;
        public GameOverScreen(Game game) : base(game)
        {
            
            Game1 g = (Game1)game;
            this.spriteBatch = g.spriteBatch;
            helpImg = g.Content.Load<Texture2D>("gameOver");
            SpriteFont regularFont = g.Content.Load<SpriteFont>("regularFont");
            RegularFont = regularFont;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(helpImg, Vector2.Zero, Color.White);
            spriteBatch.DrawString(RegularFont, "Score: " + coins.points.ToString(), new Vector2(20, 20), Color.Red);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
