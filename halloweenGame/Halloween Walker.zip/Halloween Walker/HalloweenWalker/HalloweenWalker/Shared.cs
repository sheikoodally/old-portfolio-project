﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HalloweenWalker
{
    public class Shared
    {
        public static Vector2 stage;
    }
}
