﻿using C3.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using p4_primitivesLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HalloweenWalker
{
    class Ladder : DrawableGameComponent
    {
        SpriteBatch spriteBatch;
        Background backGround;
        SpriteFont spriteFont;
        Vector2 pts = new Vector2(50, 50);

        List<Rectangle> LadderBody;
        public List<Rectangle> LADDERBODYS { get => LadderBody; }
        public Ladder(Game game, SpriteBatch spriteBatch, SpriteFont spriteFont, Background b) : base(game)
        {
            this.spriteBatch = spriteBatch;
            this.backGround = b;
            this.spriteFont = spriteFont;
            LadderBody = new List<Rectangle>();

            LadderBody.Add(new Rectangle(64, 152, 56, 233));
            LadderBody.Add(new Rectangle(322, 392, 50, 244));
            LadderBody.Add(new Rectangle(636, 291, 48, 346));
            LadderBody.Add(new Rectangle(999, 90, 43, 197));
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            foreach (Rectangle r in LadderBody)
            {
                spriteBatch.DrawRectangle(r, Color.Transparent);
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
        public static bool check = false;
        Rectangle secondRect = new Rectangle(0, 0, 0, 0);
        protected void DetectCollision()
        {
            Rectangle firstRect = new Rectangle(Player.player.X, Player.player.Y, Player.player.Width, Player.player.Height);

            for (int i = 0; i <= 3; i++)
            {
                if (firstRect.Intersects(LadderBody[i]))
                {
                    KeyboardState keyState = Keyboard.GetState();
                    if (keyState.IsKeyDown(Keys.W) || keyState.IsKeyDown(Keys.Up))
                        Player.velocity.Y = -Player.SPEED;
                }
            }
        }

        public override void Update(GameTime gameTime)
        {
            DetectCollision();
            base.Update(gameTime);
        }
    }
}
