﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C3.XNA;
using Microsoft.Xna.Framework.Input;
using PROG2370CollisionLibrary;
using Microsoft.Xna.Framework.Media;
using HalloweenWalker;
using Microsoft.Xna.Framework.Audio;

namespace p4_primitivesLibrary
{
    class Player : DrawableGameComponent
    {
        public static Boolean jumping = false;

        const int TILESIZE = 55;

        const int StandWidth = 66;     //all values from spritesheet.txt
        const int StandHeight = 120;
        const int WalkWidth = 70;
        const int WalkHeight = 120;
        const int JumpWidth = 76;
        const int JumpHeight = 120;
        const float Scale = 0.70f;

        const int StandFrame = 0;
        const int FirstWalkFrame = 1;
        const int WalkFrame = 10;
        const int JumpFrame = 11;

        public static int currentFrame = StandFrame;

        int currentFrameDelay = 0;
        const int MAXFRAMEDELAY = 3;


        List<Rectangle> FramePlayer;
        SpriteEffects spriteDirection;

        public static float SPEED = 1.6f;
        const float GRAVITY = 0.009f;

        bool isJumping = false;
        bool isGrounded = false;
        const double JUMPPOWER = -6.5;
        double currentJumpPower = 0;
        const float JUMPSTEP = 1.3f;

        public static Vector2 velocity;

        SpriteBatch spriteBatch;
        public static Texture2D playerTexture;

        public static Rectangle player;           // containing rectangle

        Rectangle playerTextureRectangle;  // the size of the raw texture 

        Background backGround;
        public Player(Game game, SpriteBatch spriteBatch, Texture2D playerTexture, Background b) : base(game)
        {
            this.spriteBatch = spriteBatch;
            Player.playerTexture = playerTexture;
            this.backGround = b;

            playerTextureRectangle = new Rectangle(0, 0, 66, 92);       // frame

            player = new Rectangle(0, 0, (int)(StandWidth * Scale), (int)(StandHeight * Scale));

            FramePlayer = new List<Rectangle>();

            //add the stand frame
            FramePlayer.Add(new Rectangle(71, 14, StandWidth, StandHeight));

            //the walk frames
            //FramePlayer.Add(new Rectangle(221, 17, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(299, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(299, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(299, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(372, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(372, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(372, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(372, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(299, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(299, 15, WalkWidth, WalkHeight));
            FramePlayer.Add(new Rectangle(299, 15, WalkWidth, WalkHeight));

            //the jump frame
            FramePlayer.Add(new Rectangle(682, 18, JumpWidth, JumpHeight));

            spriteDirection = SpriteEffects.None;

             velocity = new Vector2(0);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(playerTexture,
                    player,     //containing rectangle
                    FramePlayer.ElementAt<Rectangle>(currentFrame),     // key frame rectangle
                    Color.White,
                    0f,             //rotation
                    new Vector2(0),     // no change to origin
                    spriteDirection,
                    0f);
            spriteBatch.DrawRectangle(player, Color.Transparent);
            spriteBatch.End();
            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {

            velocity.X = 0;     //always evaluate from standing

            float deltaTime = (float)gameTime.ElapsedGameTime.Milliseconds;
            velocity.Y += deltaTime * GRAVITY;   // enable/disable gravity

            KeyboardState keyState = Keyboard.GetState();

            if (keyState.IsKeyDown(Keys.D) || keyState.IsKeyDown(Keys.Right))
                velocity.X = SPEED;

            if (keyState.IsKeyDown(Keys.A) || keyState.IsKeyDown(Keys.Left))
                velocity.X = -SPEED;

            //if (keyState.IsKeyDown(Keys.S) || keyState.IsKeyDown(Keys.Down))
            //    velocity.Y = SPEED;

            //if (keyState.IsKeyDown(Keys.W) || keyState.IsKeyDown(Keys.Up))
            //    velocity.Y = -SPEED;

            if (keyState.IsKeyDown(Keys.Space))
            {
                if (!isJumping && isGrounded)  //not already jumping, and not falling
                {
                    jumping = true;
                    isJumping = true;
                    isGrounded = false;
                    currentJumpPower =JUMPPOWER;
                }
            }

            if (isJumping)
            {
                if (currentJumpPower < 0)
                {
                    velocity.Y -= JUMPSTEP;
                    currentJumpPower++;
                }
                else
                {
                    isJumping = false; //falling
                }
            }

            // where we plan to go:
            Rectangle proposedPlayer = new Rectangle(player.X + (int)velocity.X,
                                                        player.Y + (int)velocity.Y,
                                                        player.Width,
                                                        player.Height);
            // will plan work?
            Sides collisionSides = proposedPlayer.CheckCollisions(backGround.RigidBodyList);

            if ((collisionSides & Sides.RIGHT) == Sides.RIGHT)
                if (velocity.X > 0)
                    velocity.X = 0;

            if ((collisionSides & Sides.LEFT) == Sides.LEFT)
                if (velocity.X < 0)
                    velocity.X = 0;

            if ((collisionSides & Sides.TOP) == Sides.TOP)
                if (velocity.Y < 0)
                    velocity.Y = 0;

            if ((collisionSides & Sides.BOTTOM) == Sides.BOTTOM && (currentJumpPower != JUMPPOWER))
            {
                velocity.Y = 0;
                isGrounded = true;
            }

            player.X = player.X + (int)velocity.X;
            player.Y = player.Y + (int)velocity.Y;

            //anim start
            //walking
            if (velocity.X > 0)          // face the right direction
            {
                spriteDirection = SpriteEffects.FlipHorizontally;
            }
            else if (velocity.X < 0)
            {
                spriteDirection = SpriteEffects.None;
            }

            if (isGrounded)      // player on ground
            {
                if (nearlyZero(velocity.X))         // and not moving
                {
                    currentFrame = StandFrame;
                }
                else                                // not not-moving.
                {
                    currentFrameDelay++;
                    if (currentFrameDelay > MAXFRAMEDELAY)
                    {
                        currentFrameDelay = 0;
                        currentFrame++;
                    }
                    if (currentFrame > WalkFrame)
                        currentFrame = FirstWalkFrame;
                }
            }

            //jumping
            if (isJumping)
            {
                currentFrame = JumpFrame;              
            }
            base.Update(gameTime);
        }

        private bool nearlyZero(float f1)
        {
            return (Math.Abs(f1) < float.Epsilon);
        }
    }
}
