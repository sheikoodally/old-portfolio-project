﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C3.XNA;
using Microsoft.Xna.Framework.Input;
using p4_primitivesLibrary;

namespace HalloweenWalker
{
    class Fire : DrawableGameComponent
    {
        SpriteBatch spriteBatch;
        Background backGround;
        SpriteFont spriteFont;
        Vector2 pts = new Vector2(50, 50);

        List<Rectangle> FireBody;
        public List<Rectangle> FIREBODYS { get => FireBody; }
        public Fire(Game game, SpriteBatch spriteBatch, SpriteFont spriteFont,  Background b) : base(game)
        {
            this.spriteBatch = spriteBatch;
            this.backGround = b;
            this.spriteFont = spriteFont;
            FireBody = new List<Rectangle>();

            FireBody.Add(new Rectangle(485, 621, 52, 80));
            FireBody.Add(new Rectangle(815, 265, 50, 85));
            FireBody.Add(new Rectangle(1132, 395, 58, 67));      
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            foreach (Rectangle r in FireBody)
            {
                spriteBatch.DrawRectangle(r, Color.Transparent);
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
        public static bool check = false;
        Rectangle secondRect = new Rectangle(0, 0, 0, 0);
        protected void DetectCollision()
        {
            Rectangle firstRect = new Rectangle(Player.player.X, Player.player.Y, Player.player.Width, Player.player.Height);

            for (int i = 0; i <= 2; i++)
            {
                if (firstRect.Intersects(FireBody[i]))
                {
                    FireBody[i] = new Rectangle(5000, 5000, 5, 5);
                    check = true;                    
                }
            }
        }

        public override void Update(GameTime gameTime)
        {
            DetectCollision();
            base.Update(gameTime);
        }
    }
}
